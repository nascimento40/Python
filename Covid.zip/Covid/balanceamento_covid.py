import pandas as pd
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import RandomOverSampler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
import glob

def carregar_dados(caminho):
    arquivos = glob.glob("dados/lbp-train-fold_*.csv")
    lista_dfs = [pd.read_csv(arquivo) for arquivo in arquivos]
    dados = pd.concat(lista_dfs, ignore_index=True)
    return dados

def balancear_dados(X, y):
    balanceador = RandomOverSampler(random_state=42)
    X_balanceado, y_balanceado = balanceador.fit_resample(X, y)
    return X_balanceado, y_balanceado

caminho = "caminho_para_seus_arquivos"

dados = carregar_dados(caminho)
X = dados.drop(columns='class') 
y = dados['class'] 

X_treino, X_teste, y_treino, y_teste = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

X_treino_balanceado, y_treino_balanceado = balancear_dados(X_treino, y_treino)

modelo = LogisticRegression(max_iter=1000)
modelo.fit(X_treino_balanceado, y_treino_balanceado)

y_previsao = modelo.predict(X_teste)
print("Acurácia:", accuracy_score(y_teste, y_previsao))
print(classification_report(y_teste, y_previsao))
